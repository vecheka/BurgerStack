/*
 * TCSS 342- Assignment 1 
 */

/**
 * @author Vecheka Chhourn
 * @version 03/27/2018
 *
 */
public class Veggies {
	
	/** Lettuce.*/
	private String myLettuce;
	/** Tomato.*/
	private String myTomato;
	/** Onions.*/
	private String myOnions;
	/** Pickle.*/
	private String myPickle;
	/** Mushrooms.*/
	private String myMushroom;
	
	/**
	 * Constructor to initialize all veggies type.
	 */
	public Veggies() {
		myLettuce = "Lettuce";
		myTomato = "Tomato";
		myOnions = "Onions";
		myPickle = "Pickle";
		myMushroom = "Mushrooms";
	}
	
	/**
	 * Getter for lettuce.
	 * @return lettuce
	 */
	public String getLettuce() {
		return myLettuce;
	}
	
	/**
	 * Getter for onions.
	 * @return onions
	 */
	public String getOnions() {
		return myOnions;
	}
	
	/**
	 * Getter for tomato.
	 * @return tomato
	 */
	public String getTomato() {
		return myTomato;
	}
	
	/**
	 * Getter for pickle.
	 * @return pickle
	 */
	public String getPickle() {
		return myPickle;
	}
	
	/**
	 * Getter for mushrooms.
	 * @return mushrooms
	 */
	public String getMushrooms() {
		return myMushroom;
	}
	
	/** 
	 * Check if it is a veggie.
	 * @param theType type of ingredients on the burger.
	 * @return true if it is a veggie.
	 */
	public boolean isVeggie(final String theType) {
		return (theType.equals(myLettuce) 
				|| theType.equals(myTomato)
				|| theType.equals(myOnions)
				|| theType.equals(myPickle)
				|| theType.equals(myMushroom)
				|| theType.equalsIgnoreCase("Veggies"));
	}
	
}
