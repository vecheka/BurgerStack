/*
 * TCSS 342- Assignment 1 
 */

/**
 * @author Vecheka Chhourn
 * @version 03/27/2018
 *
 */
public class Cheese {
	
	/**Cheddar chesse.*/
	private String myCheddar;
	/**Mozzarrella chesse.*/
	private String myMozzarella;
	/**Pepperjack chesse.*/
	private String myPepperjack;
	
	/**
	 * Constructor to initialize chesse types.
	 */
	public Cheese() {
		myCheddar = "Cheddar";
		myMozzarella = "Mozzarella";
		myPepperjack = "Pepperjack";
		
	}
	
	/**
	 * Getter for cheddar.
	 * @return cheddar
	 */
	
	public String getCheddar() {
		return myCheddar;
	}
	
	/**
	 * Getter for Mozzarrella.
	 * @return Mozzarrella
	 */
	
	public String getMozzarella() {
		return myMozzarella;
	}
	
	/**
	 * Getter for Pepperjack.
	 * @return Pepperjack
	 */
	
	public String getPepperjack() {
		return myPepperjack;
	}
	
	/** 
	 * Check if it is a chesse.
	 * @param theType type of ingredients on the burger.
	 * @return true if it is a chesse.
	 */
	public boolean isCheese(final String theType) {
		return (theType.equals(myPepperjack)
				|| theType.equals(myMozzarella)
				|| theType.equals(myCheddar)
				|| theType.equals("Cheese"));
	}
	
}
