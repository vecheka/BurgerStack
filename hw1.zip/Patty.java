/*
 * TCSS 342- Assignment 1 
 */

/**
 * @author Vecheka Chhourn
 * @version 03/27/2018
 *
 */
public class Patty {
	
	/** Beef.*/
	private String myBeef;
	/** Chicken.*/
	private String myChicken;
	/** Veggie.*/
	private String myVeggie;
	
	/**
	 * Constructor to initialize all patty types.
	 */
	public Patty() {
		myBeef = "Beef";
		myChicken = "Chicken";
		myVeggie = "Veggie";
	}
	
	/**
	 * Getter for beef.
	 * @return beef.
	 */
	public String getBeef() {
		return myBeef;
	}
	
	/**
	 * Getter for chicken.
	 * @return chicken.
	 */
	public String getChicken() {
		return myChicken;
	}
	
	/**
	 * Getter for veggie.
	 * @return veggie.
	 */
	public String getVeggie() {
		return myVeggie;
	}
	
	/** 
	 * Check if it is a patty.
	 * @param theType type of ingredients on the burger.
	 * @return true if it is a patty.
	 */
	public boolean isPatty(final String theType) {
		return (theType == myBeef 
				|| theType == myChicken
				|| theType == myVeggie);
	}
	
}
