/*
 * TCSS 342- Assignment 1 
 */

/**
 * @author Vecheka Chhourn
 * @version 03/27/2018
 *
 */
public class Sauces {
	
	/** Ketchup.*/
	private String myKetchup;
	/** Mustard.*/
	private String myMustard;
	/** Mayonnaise.*/
	private String myMayonnaise;
	/** Baron-Sauce.*/
	private String myBaronSauce;
	
	/** 
	 * Constructor to initialize all sauces type.
	 */
	public Sauces() {
		myKetchup = "Ketchup";
		myMustard = "Mustard";
		myMayonnaise = "Mayonnaise";
		myBaronSauce = "Baron-Sauce";
	}
	
	
	/**
	 * Getter for ketchup.
	 * @return ketchup
	 */
	public String getKetchup() {
		return myKetchup;
	}
	
	/**
	 * Getter for mustard.
	 * @return mustard
	 */
	public String getMustard() {
		return myMustard;
	}
	
	/**
	 * Getter for mayonnaise.
	 * @return mayonnaise
	 */
	public String getMayonnaise() {
		return myMayonnaise;
	}
	
	/**
	 * Getter for Baron Sauce.
	 * @return Baron Sauce
	 */
	public String getBaronSauce() {
		return myBaronSauce;
	}
	
	/** 
	 * Check if it is a sauce.
	 * @param theType type of ingredients on the burger.
	 * @return true if it is a sauce.
	 */
	public boolean isSauce(final String theType) {
		return (theType.equals(myKetchup)
				|| theType.equals(myMustard)
				|| theType.equals(myMayonnaise)
				|| theType.equals(myBaronSauce)
				|| theType.equals("Sauce"));
	}
	
}
