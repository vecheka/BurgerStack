/*
 * TCSS 342- Assignment 1 
 */

/**
 * @author Vecheka Chhourn
 * @version 03/26/2018
 * A class that creates a node to link elements together.
 * @param <E> generic data
 */
public class StackNode<E> {
	
	/** Stack elements.*/
	protected E data;
	/** Pointer to next element in the stack.*/
	protected StackNode<E> next;
	
	
	/**
	 * Constructor to add next element to the top of the stack.
	 * @param theData element to add to the top of the stack
	 */
	public StackNode(final E theData) {
		this.data = theData;
	}
}
